﻿Public Class INDIVIDUAL_REC

End Class